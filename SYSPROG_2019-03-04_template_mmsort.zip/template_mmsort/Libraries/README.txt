Die Dateien muessen in folgenden Pfad:

/home/dhbw/dev/tools/arm-bcm2708/gcc-linaro-arm-linux-gnueabihf-raspbian-x64/arm-linux-gnueabihf/lib
