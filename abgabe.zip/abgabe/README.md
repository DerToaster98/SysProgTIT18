# Abgabedateien

Gruppe: Lisa Binkert, Nikolai Klatt, Samuel Rundel, Oliver Seiler, Patrick Sewell

## Quellcode

`main.s`

Zum ins Template Einfügen.

Enthält auch Ansätze zu den Bonusaufgaben; Sprünge zu den entsprechenden Programmabschnitten wurden auskommentiert.

## Kompilat

`MMSort_mmap`

## Dokumentation und Lösungen zu den Theorieaufgaben

Dokumentation.pdf

